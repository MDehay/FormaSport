<?php

// on recupere tous les donnees de creation de la reunion contenus dans un tableaux que l'on stocke dans des variables

$login=reunion()[0];

$objet=reunion()[1];

$description=reunion()[2];

$lieu=reunion()[3];

$selected_lieux=reunion()[4];

$date_reunion_1=reunion()[5];

$date_validite=reunion()[6];

$creneau_debut_1=reunion()[7];

$creneau_fin_1=reunion()[8];

$creneau_debut_2=reunion()[9];

$creneau_fin_2=reunion()[10];

$date_reunion_2=reunion()[11];

$creneau_debut_3=reunion()[12];

$creneau_fin_3=reunion()[13];

$creneau_debut_4=reunion()[14];

$creneau_fin_4=reunion()[15];

$personne_inviter_1=reunion()[16];

$personne_inviter_2=reunion()[17];

$personne_inviter_3=reunion()[18];

$personne_inviter_4=reunion()[19];

$personne_inviter_5=reunion()[20];

$personne_inviter_6=reunion()[21];

$personne_inviter_7=reunion()[22];

$personne_indispensable_1=reunion()[23];

$personne_indispensable_2=reunion()[24];

$personne_indispensable_3=reunion()[25];

$personne_indispensable_4=reunion()[26];

$personne_indispensable_5=reunion()[27];

$personne_indispensable_6=reunion()[28];

$personne_indispensable_7=reunion()[29];
?>



