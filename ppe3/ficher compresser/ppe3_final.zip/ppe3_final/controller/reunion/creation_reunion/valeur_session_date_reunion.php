<?php

include_once 'function_session.php';
// on recupere tous les donnes du tableau qui contient les differentes date de la reunion dans des variables

$date_reunion_1=date_reunion()[0];

$date_validite=date_reunion()[1];

$creneau_debut_1=date_reunion()[2];

$creneau_fin_1=date_reunion()[3];

$creneau_debut_2=date_reunion()[4];

$creneau_fin_2=date_reunion()[5];

$date_reunion_2=date_reunion()[6];

$creneau_debut_3=date_reunion()[7];

$creneau_fin_3=date_reunion()[8];

$creneau_debut_4=date_reunion()[9];

$creneau_fin_4=date_reunion()[10];

?>