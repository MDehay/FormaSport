<?php
$update_objet=modif_update_reunion()[0];
$update_description=modif_update_reunion()[1];
$update_lieux=modif_update_reunion()[2];
$update_selected_lieux=modif_update_reunion()[3];
$update_date_reunion_1=modif_update_reunion()[4];
$update_date_validite=modif_update_reunion()[5];
$update_creneau_debut_1=modif_update_reunion()[6];
$update_creneau_fin_1=modif_update_reunion()[7];
$update_personne_inviter_1=modif_update_reunion()[8];
$update_personne_indispensable_1=modif_update_reunion()[9];

?>