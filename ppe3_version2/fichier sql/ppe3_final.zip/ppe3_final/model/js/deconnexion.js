$(function() {
    $("button.btn.btn-danger.my-2.my-sm-0").click(function () {

        $(location).attr('href', '../../index.php?login=deconnexion')
    });
});