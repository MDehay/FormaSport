function personne_inviter_1_indispensable_1_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_1_indispensable_1_identique = true;

    if ($("#select_personne_inviter_1").val() == $("#select_personne_indispensable_1").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_1").addClass("border_erreur_champ");
        $("#select_personne_indispensable_1").addClass("border_erreur_champ");
        personne_inviter_1_indispensable_1_identique = false;
    }
    return personne_inviter_1_indispensable_1_identique;
}

function personne_inviter_1_indispensable_2_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_1_indispensable_2_identique = true;

    if ($("#select_personne_inviter_1").val() == $("#select_personne_indispensable_2").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_1").addClass("border_erreur_champ");
        $("#select_personne_indispensable_2").addClass("border_erreur_champ");
        personne_inviter_1_indispensable_2_identique = false;
    }
    return personne_inviter_1_indispensable_2_identique;
}

function personne_inviter_1_indispensable_3_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_1_indispensable_3_identique = true;

    if ($("#select_personne_inviter_1").val() == $("#select_personne_indispensable_3").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_1").addClass("border_erreur_champ");
        $("#select_personne_indispensable_3").addClass("border_erreur_champ");
        personne_inviter_1_indispensable_3_identique = false;
    }
    return personne_inviter_1_indispensable_3_identique;
}

function personne_inviter_1_indispensable_4_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_1_indispensable_4_identique = true;

    if ($("#select_personne_inviter_1").val() == $("#select_personne_indispensable_4").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_1").addClass("border_erreur_champ");
        $("#select_personne_indispensable_4").addClass("border_erreur_champ");
        personne_inviter_1_indispensable_4_identique = false;
    }
    return personne_inviter_1_indispensable_4_identique;
}

function personne_inviter_1_indispensable_5_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_1_indispensable_5_identique = true;

    if ($("#select_personne_inviter_1").val() == $("#select_personne_indispensable_5").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_1").addClass("border_erreur_champ");
        $("#select_personne_indispensable_5").addClass("border_erreur_champ");
        personne_inviter_1_indispensable_5_identique = false;
    }
    return personne_inviter_1_indispensable_5_identique;
}

function personne_inviter_1_indispensable_6_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_1_indispensable_6_identique = true;

    if ($("#select_personne_inviter_1").val() == $("#select_personne_indispensable_6").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_1").addClass("border_erreur_champ");
        $("#select_personne_indispensable_6").addClass("border_erreur_champ");
        personne_inviter_1_indispensable_6_identique = false;
    }
    return personne_inviter_1_indispensable_6_identique;
}

function personne_inviter_1_indispensable_7_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_1_indispensable_7_identique = true;

    if ($("#select_personne_inviter_1").val() == $("#select_personne_indispensable_7").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_1").addClass("border_erreur_champ");
        $("#select_personne_indispensable_7").addClass("border_erreur_champ");
        personne_inviter_1_indispensable_7_identique = false;
    }
    return personne_inviter_1_indispensable_7_identique;
}
function personne_inviter_2_indispensable_1_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_2_indispensable_1_identique = true;

    if ($("#select_personne_inviter_2").val() == $("#select_personne_indispensable_1").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_2").addClass("border_erreur_champ");
        $("#select_personne_indispensable_1").addClass("border_erreur_champ");
        personne_inviter_2_indispensable_1_identique = false;
    }
    return personne_inviter_2_indispensable_1_identique;
}

function personne_inviter_2_indispensable_2_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_2_indispensable_2_identique = true;

    if ($("#select_personne_inviter_2").val() == $("#select_personne_indispensable_2").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_2").addClass("border_erreur_champ");
        $("#select_personne_indispensable_2").addClass("border_erreur_champ");
        personne_inviter_2_indispensable_2_identique = false;
    }
    return personne_inviter_2_indispensable_2_identique;
}

function personne_inviter_2_indispensable_3_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_2_indispensable_3_identique = true;

    if ($("#select_personne_inviter_2").val() == $("#select_personne_indispensable_3").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_2").addClass("border_erreur_champ");
        $("#select_personne_indispensable_3").addClass("border_erreur_champ");
        personne_inviter_2_indispensable_3_identique = false;
    }
    return personne_inviter_2_indispensable_3_identique;
}

function personne_inviter_2_indispensable_4_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_2_indispensable_4_identique = true;

    if ($("#select_personne_inviter_2").val() == $("#select_personne_indispensable_4").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_2").addClass("border_erreur_champ");
        $("#select_personne_indispensable_4").addClass("border_erreur_champ");
        personne_inviter_2_indispensable_4_identique = false;
    }
    return personne_inviter_2_indispensable_4_identique;
}

function personne_inviter_2_indispensable_5_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_2_indispensable_5_identique = true;

    if ($("#select_personne_inviter_2").val() == $("#select_personne_indispensable_5").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_2").addClass("border_erreur_champ");
        $("#select_personne_indispensable_5").addClass("border_erreur_champ");
        personne_inviter_2_indispensable_5_identique = false;
    }
    return personne_inviter_2_indispensable_5_identique;
}

function personne_inviter_2_indispensable_6_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_2_indispensable_6_identique = true;

    if ($("#select_personne_inviter_2").val() == $("#select_personne_indispensable_6").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_2").addClass("border_erreur_champ");
        $("#select_personne_indispensable_6").addClass("border_erreur_champ");
        personne_inviter_2_indispensable_6_identique = false;
    }
    return personne_inviter_2_indispensable_6_identique;
}

function personne_inviter_2_indispensable_7_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_2_indispensable_7_identique = true;

    if ($("#select_personne_inviter_2").val() == $("#select_personne_indispensable_7").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_2").addClass("border_erreur_champ");
        $("#select_personne_indispensable_7").addClass("border_erreur_champ");
        personne_inviter_2_indispensable_7_identique = false;
    }
    return personne_inviter_2_indispensable_7_identique;
}
function personne_inviter_3_indispensable_1_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_3_indispensable_1_identique = true;

    if ($("#select_personne_inviter_3").val() == $("#select_personne_indispensable_1").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_3").addClass("border_erreur_champ");
        $("#select_personne_indispensable_1").addClass("border_erreur_champ");
        personne_inviter_3_indispensable_1_identique = false;
    }
    return personne_inviter_3_indispensable_1_identique;
}

function personne_inviter_3_indispensable_2_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_3_indispensable_2_identique = true;

    if ($("#select_personne_inviter_3").val() == $("#select_personne_indispensable_2").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_3").addClass("border_erreur_champ");
        $("#select_personne_indispensable_2").addClass("border_erreur_champ");
        personne_inviter_3_indispensable_2_identique = false;
    }
    return personne_inviter_3_indispensable_2_identique;
}

function personne_inviter_3_indispensable_3_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_3_indispensable_3_identique = true;

    if ($("#select_personne_inviter_3").val() == $("#select_personne_indispensable_3").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_3").addClass("border_erreur_champ");
        $("#select_personne_indispensable_3").addClass("border_erreur_champ");
        personne_inviter_3_indispensable_3_identique = false;
    }
    return personne_inviter_3_indispensable_3_identique;
}

function personne_inviter_3_indispensable_4_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_3_indispensable_4_identique = true;

    if ($("#select_personne_inviter_3").val() == $("#select_personne_indispensable_4").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_3").addClass("border_erreur_champ");
        $("#select_personne_indispensable_4").addClass("border_erreur_champ");
        personne_inviter_3_indispensable_4_identique = false;
    }
    return personne_inviter_3_indispensable_4_identique;
}

function personne_inviter_3_indispensable_5_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_3_indispensable_5_identique = true;

    if ($("#select_personne_inviter_3").val() == $("#select_personne_indispensable_5").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_3").addClass("border_erreur_champ");
        $("#select_personne_indispensable_5").addClass("border_erreur_champ");
        personne_inviter_3_indispensable_5_identique = false;
    }
    return personne_inviter_3_indispensable_5_identique;
}

function personne_inviter_3_indispensable_6_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_3_indispensable_6_identique = true;

    if ($("#select_personne_inviter_3").val() == $("#select_personne_indispensable_6").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_3").addClass("border_erreur_champ");
        $("#select_personne_indispensable_6").addClass("border_erreur_champ");
        personne_inviter_3_indispensable_6_identique = false;
    }
    return personne_inviter_3_indispensable_6_identique;
}

function personne_inviter_3_indispensable_7_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_3_indispensable_7_identique = true;

    if ($("#select_personne_inviter_3").val() == $("#select_personne_indispensable_7").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_3").addClass("border_erreur_champ");
        $("#select_personne_indispensable_7").addClass("border_erreur_champ");
        personne_inviter_3_indispensable_7_identique = false;
    }
    return personne_inviter_3_indispensable_7_identique;
}
function personne_inviter_4_indispensable_1_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_4_indispensable_1_identique = true;

    if ($("#select_personne_inviter_4").val() == $("#select_personne_indispensable_1").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_4").addClass("border_erreur_champ");
        $("#select_personne_indispensable_1").addClass("border_erreur_champ");
        personne_inviter_4_indispensable_1_identique = false;
    }
    return personne_inviter_4_indispensable_1_identique;
}

function personne_inviter_4_indispensable_2_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_4_indispensable_2_identique = true;

    if ($("#select_personne_inviter_4").val() == $("#select_personne_indispensable_2").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_4").addClass("border_erreur_champ");
        $("#select_personne_indispensable_2").addClass("border_erreur_champ");
        personne_inviter_4_indispensable_2_identique = false;
    }
    return personne_inviter_4_indispensable_2_identique;
}

function personne_inviter_4_indispensable_3_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_4_indispensable_3_identique = true;

    if ($("#select_personne_inviter_4").val() == $("#select_personne_indispensable_3").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_4").addClass("border_erreur_champ");
        $("#select_personne_indispensable_3").addClass("border_erreur_champ");
        personne_inviter_4_indispensable_3_identique = false;
    }
    return personne_inviter_4_indispensable_3_identique;
}

function personne_inviter_4_indispensable_4_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_4_indispensable_4_identique = true;

    if ($("#select_personne_inviter_4").val() == $("#select_personne_indispensable_4").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_4").addClass("border_erreur_champ");
        $("#select_personne_indispensable_4").addClass("border_erreur_champ");
        personne_inviter_4_indispensable_4_identique = false;
    }
    return personne_inviter_4_indispensable_4_identique;
}

function personne_inviter_4_indispensable_5_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_4_indispensable_5_identique = true;

    if ($("#select_personne_inviter_4").val() == $("#select_personne_indispensable_5").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_4").addClass("border_erreur_champ");
        $("#select_personne_indispensable_5").addClass("border_erreur_champ");
        personne_inviter_4_indispensable_5_identique = false;
    }
    return personne_inviter_4_indispensable_5_identique;
}

function personne_inviter_4_indispensable_6_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_4_indispensable_6_identique = true;

    if ($("#select_personne_inviter_4").val() == $("#select_personne_indispensable_6").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_4").addClass("border_erreur_champ");
        $("#select_personne_indispensable_6").addClass("border_erreur_champ");
        personne_inviter_4_indispensable_6_identique = false;
    }
    return personne_inviter_4_indispensable_6_identique;
}

function personne_inviter_4_indispensable_7_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_4_indispensable_7_identique = true;

    if ($("#select_personne_inviter_4").val() == $("#select_personne_indispensable_7").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_4").addClass("border_erreur_champ");
        $("#select_personne_indispensable_7").addClass("border_erreur_champ");
        personne_inviter_4_indispensable_7_identique = false;
    }
    return personne_inviter_4_indispensable_7_identique;
}
function personne_inviter_5_indispensable_1_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_5_indispensable_1_identique = true;

    if ($("#select_personne_inviter_5").val() == $("#select_personne_indispensable_1").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_5").addClass("border_erreur_champ");
        $("#select_personne_indispensable_1").addClass("border_erreur_champ");
        personne_inviter_5_indispensable_1_identique = false;
    }
    return personne_inviter_5_indispensable_1_identique;
}

function personne_inviter_5_indispensable_2_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_5_indispensable_2_identique = true;

    if ($("#select_personne_inviter_5").val() == $("#select_personne_indispensable_2").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_5").addClass("border_erreur_champ");
        $("#select_personne_indispensable_2").addClass("border_erreur_champ");
        personne_inviter_5_indispensable_2_identique = false;
    }
    return personne_inviter_5_indispensable_2_identique;
}

function personne_inviter_5_indispensable_3_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_5_indispensable_3_identique = true;

    if ($("#select_personne_inviter_5").val() == $("#select_personne_indispensable_3").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_5").addClass("border_erreur_champ");
        $("#select_personne_indispensable_3").addClass("border_erreur_champ");
        personne_inviter_5_indispensable_3_identique = false;
    }
    return personne_inviter_5_indispensable_3_identique;
}

function personne_inviter_5_indispensable_4_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_5_indispensable_4_identique = true;

    if ($("#select_personne_inviter_5").val() == $("#select_personne_indispensable_4").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_5").addClass("border_erreur_champ");
        $("#select_personne_indispensable_4").addClass("border_erreur_champ");
        personne_inviter_5_indispensable_4_identique = false;
    }
    return personne_inviter_5_indispensable_4_identique;
}

function personne_inviter_5_indispensable_5_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_5_indispensable_5_identique = true;

    if ($("#select_personne_inviter_5").val() == $("#select_personne_indispensable_5").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_5").addClass("border_erreur_champ");
        $("#select_personne_indispensable_5").addClass("border_erreur_champ");
        personne_inviter_5_indispensable_5_identique = false;
    }
    return personne_inviter_5_indispensable_5_identique;
}

function personne_inviter_5_indispensable_6_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_5_indispensable_6_identique = true;

    if ($("#select_personne_inviter_5").val() == $("#select_personne_indispensable_6").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_5").addClass("border_erreur_champ");
        $("#select_personne_indispensable_6").addClass("border_erreur_champ");
        personne_inviter_5_indispensable_6_identique = false;
    }
    return personne_inviter_5_indispensable_6_identique;
}

function personne_inviter_5_indispensable_7_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_5_indispensable_7_identique = true;

    if ($("#select_personne_inviter_5").val() == $("#select_personne_indispensable_7").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_5").addClass("border_erreur_champ");
        $("#select_personne_indispensable_7").addClass("border_erreur_champ");
        personne_inviter_5_indispensable_7_identique = false;
    }
    return personne_inviter_5_indispensable_7_identique;
}
function personne_inviter_6_indispensable_1_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_6_indispensable_1_identique = true;

    if ($("#select_personne_inviter_6").val() == $("#select_personne_indispensable_1").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_6").addClass("border_erreur_champ");
        $("#select_personne_indispensable_1").addClass("border_erreur_champ");
        personne_inviter_6_indispensable_1_identique = false;
    }
    return personne_inviter_6_indispensable_1_identique;
}

function personne_inviter_6_indispensable_2_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_6_indispensable_2_identique = true;

    if ($("#select_personne_inviter_6").val() == $("#select_personne_indispensable_2").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_6").addClass("border_erreur_champ");
        $("#select_personne_indispensable_2").addClass("border_erreur_champ");
        personne_inviter_6_indispensable_2_identique = false;
    }
    return personne_inviter_6_indispensable_2_identique;
}

function personne_inviter_6_indispensable_3_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_6_indispensable_3_identique = true;

    if ($("#select_personne_inviter_6").val() == $("#select_personne_indispensable_3").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_6").addClass("border_erreur_champ");
        $("#select_personne_indispensable_3").addClass("border_erreur_champ");
        personne_inviter_6_indispensable_3_identique = false;
    }
    return personne_inviter_6_indispensable_3_identique;
}

function personne_inviter_6_indispensable_4_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_6_indispensable_4_identique = true;

    if ($("#select_personne_inviter_6").val() == $("#select_personne_indispensable_4").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_6").addClass("border_erreur_champ");
        $("#select_personne_indispensable_4").addClass("border_erreur_champ");
        personne_inviter_6_indispensable_4_identique = false;
    }
    return personne_inviter_6_indispensable_4_identique;
}

function personne_inviter_6_indispensable_5_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_6_indispensable_5_identique = true;

    if ($("#select_personne_inviter_6").val() == $("#select_personne_indispensable_5").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_6").addClass("border_erreur_champ");
        $("#select_personne_indispensable_5").addClass("border_erreur_champ");
        personne_inviter_6_indispensable_5_identique = false;
    }
    return personne_inviter_6_indispensable_5_identique;
}

function personne_inviter_6_indispensable_6_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_6_indispensable_6_identique = true;

    if ($("#select_personne_inviter_6").val() == $("#select_personne_indispensable_6").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_6").addClass("border_erreur_champ");
        $("#select_personne_indispensable_6").addClass("border_erreur_champ");
        personne_inviter_6_indispensable_6_identique = false;
    }
    return personne_inviter_6_indispensable_6_identique;
}

function personne_inviter_6_indispensable_7_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_6_indispensable_7_identique = true;

    if ($("#select_personne_inviter_6").val() == $("#select_personne_indispensable_7").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_6").addClass("border_erreur_champ");
        $("#select_personne_indispensable_7").addClass("border_erreur_champ");
        personne_inviter_6_indispensable_7_identique = false;
    }
    return personne_inviter_6_indispensable_7_identique;
}
function personne_inviter_7_indispensable_1_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_7_indispensable_1_identique = true;

    if ($("#select_personne_inviter_7").val() == $("#select_personne_indispensable_1").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_7").addClass("border_erreur_champ");
        $("#select_personne_indispensable_1").addClass("border_erreur_champ");
        personne_inviter_7_indispensable_1_identique = false;
    }
    return personne_inviter_7_indispensable_1_identique;
}

function personne_inviter_7_indispensable_2_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_7_indispensable_2_identique = true;

    if ($("#select_personne_inviter_7").val() == $("#select_personne_indispensable_2").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_7").addClass("border_erreur_champ");
        $("#select_personne_indispensable_2").addClass("border_erreur_champ");
        personne_inviter_7_indispensable_2_identique = false;
    }
    return personne_inviter_7_indispensable_2_identique;
}

function personne_inviter_7_indispensable_3_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_7_indispensable_3_identique = true;

    if ($("#select_personne_inviter_7").val() == $("#select_personne_indispensable_3").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_7").addClass("border_erreur_champ");
        $("#select_personne_indispensable_3").addClass("border_erreur_champ");
        personne_inviter_7_indispensable_3_identique = false;
    }
    return personne_inviter_7_indispensable_3_identique;
}

function personne_inviter_7_indispensable_4_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_7_indispensable_4_identique = true;

    if ($("#select_personne_inviter_7").val() == $("#select_personne_indispensable_4").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_7").addClass("border_erreur_champ");
        $("#select_personne_indispensable_4").addClass("border_erreur_champ");
        personne_inviter_7_indispensable_4_identique = false;
    }
    return personne_inviter_7_indispensable_4_identique;
}

function personne_inviter_7_indispensable_5_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_7_indispensable_5_identique = true;

    if ($("#select_personne_inviter_7").val() == $("#select_personne_indispensable_5").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_7").addClass("border_erreur_champ");
        $("#select_personne_indispensable_5").addClass("border_erreur_champ");
        personne_inviter_7_indispensable_5_identique = false;
    }
    return personne_inviter_7_indispensable_5_identique;
}

function personne_inviter_7_indispensable_6_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_7_indispensable_6_identique = true;

    if ($("#select_personne_inviter_7").val() == $("#select_personne_indispensable_6").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_7").addClass("border_erreur_champ");
        $("#select_personne_indispensable_6").addClass("border_erreur_champ");
        personne_inviter_7_indispensable_6_identique = false;
    }
    return personne_inviter_7_indispensable_6_identique;
}

function personne_inviter_7_indispensable_7_identique () {
    // on initialise la variable de validation du formulaire
    var personne_inviter_7_indispensable_7_identique = true;

    if ($("#select_personne_inviter_7").val() == $("#select_personne_indispensable_7").val()) {
        $("span#personne_inviter_indispensable_identique").remove();
        $("h1").after('<span id="personne_inviter_indispensable_identique"> Veuillez ne pas selectionner la meme personne en inviter et indispensable </span>');
        $("span#personne_inviter_indispensable_identique").addClass("color_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("taille_erreur_champ");
        $("span#personne_inviter_indispensable_identique").addClass("border_erreur_champ");
        $("#select_personne_inviter_7").addClass("border_erreur_champ");
        $("#select_personne_indispensable_7").addClass("border_erreur_champ");
        personne_inviter_7_indispensable_7_identique = false;
    }
    return personne_inviter_7_indispensable_7_identique;
}