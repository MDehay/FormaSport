<?php
include_once '../menu/header.php';
include_once '../menu/menu.php';
include_once '../../controller/Acceuil/acceuil.php';
include_once '../menu/footer.php';
?>